Database Management
==================

.. click:: dbcan.main:cli
   :prog: run_dbcan
   :commands: database
   :nested: full

Usage Examples
--------------

Download CAZy database

.. code-block:: bash

   run_dbcan database --db_dir db