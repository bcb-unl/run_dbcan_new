CAZyme Annotation
==================

.. click:: dbcan.main:cli
   :prog: run_dbcan
   :commands: CAZyme_annotation --help
   :nested: full

Usage Examples
--------------

.. code-block:: bash



   run_dbcan CAZyme_annotation --db_dir db